<div class="mkd-separator-holder clearfix <?php echo esc_attr($holder_classes); ?>">
	<div class="mkd-separator" <?php echo entre_mikado_get_inline_style($holder_styles); ?>></div>
</div>
