<div class="mkd-uncovering-sections">
	<ul class="mkd-us-wrapper curtains" data-image-holder-name=".mkd-uss-image-holder" data-fade-element-name=".mkd-fss-shadow">
		<?php echo do_shortcode($content); ?>
	</ul>
    <div class="mkd-fss-shadow"></div>
</div>