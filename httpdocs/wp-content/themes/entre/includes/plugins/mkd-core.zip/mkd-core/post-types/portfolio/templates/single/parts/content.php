<div class="mkd-ps-info-item mkd-ps-content-item">
    <?php the_content(); ?>
</div>