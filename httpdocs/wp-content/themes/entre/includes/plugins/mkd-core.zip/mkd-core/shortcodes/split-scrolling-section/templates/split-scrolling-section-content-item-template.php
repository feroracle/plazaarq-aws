<div class="mkd-sss-ms-section" <?php echo entre_mikado_get_inline_attrs($content_data); ?> <?php entre_mikado_inline_style($content_style);?>>
	<?php echo do_shortcode($content); ?>
</div>