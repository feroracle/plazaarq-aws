<?php

include_once MIKADO_CORE_SHORTCODES_PATH.'/parallax-holder/functions.php';
include_once MIKADO_CORE_SHORTCODES_PATH.'/parallax-holder/parallax-holder.php';