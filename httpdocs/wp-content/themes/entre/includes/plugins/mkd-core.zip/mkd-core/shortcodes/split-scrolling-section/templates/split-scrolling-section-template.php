<div class="mkd-split-scrolling-section">
    <?php echo do_shortcode($content); ?>
</div>