<div class="mkd-full-screen-image-slider <?php echo esc_attr($holder_classes); ?>">
	<div class="mkd-fsis-slider mkd-owl-slider" <?php echo entre_mikado_get_inline_attrs($slider_data); ?>>
		<?php echo do_shortcode($content); ?>
	</div>
	<div class="mkd-fsis-thumb-nav mkd-fsis-prev-nav"></div>
	<div class="mkd-fsis-thumb-nav mkd-fsis-next-nav"></div>
	<div class="mkd-fsis-slider-mask"></div>
</div>