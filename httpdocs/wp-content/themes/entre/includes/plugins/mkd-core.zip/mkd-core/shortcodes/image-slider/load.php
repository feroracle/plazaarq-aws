<?php
include_once MIKADO_CORE_SHORTCODES_PATH.'/image-slider/functions.php';
include_once MIKADO_CORE_SHORTCODES_PATH.'/image-slider/image-slider.php';