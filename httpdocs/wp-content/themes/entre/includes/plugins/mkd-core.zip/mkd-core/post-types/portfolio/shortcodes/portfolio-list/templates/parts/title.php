<?php if ($enable_title === 'yes') {
	$title_tag = !empty($title_tag) ? $title_tag : 'h4';
	$title_styles = $this_object->getTitleStyles($params);
	?>
	<<?php echo entre_mikado_cpt_escape_title_tag($title_tag); ?> itemprop="name" class="mkd-pli-title entry-title" <?php entre_mikado_inline_style($title_styles); ?>>
		<?php echo esc_attr(get_the_title()); ?>
	</<?php echo entre_mikado_cpt_escape_title_tag($title_tag); ?>>
<?php } ?>