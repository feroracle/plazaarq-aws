<?php echo mkd_core_get_cpt_shortcode_module_template_part('portfolio', 'portfolio-list', 'parts/image', $item_style, $params); ?>

<div class="mkd-item-text-overlay">
    <div class="mkd-item-text-overlay-inner">
        <div class="mkd-item-text-holder">
            <?php echo mkd_core_get_cpt_shortcode_module_template_part('portfolio', 'portfolio-list', 'parts/title', $item_style, $params); ?>
            <?php echo mkd_core_get_cpt_shortcode_module_template_part('portfolio', 'portfolio-list', 'parts/category', $item_style, $params); ?>
        </div>        
    </div>
</div>
